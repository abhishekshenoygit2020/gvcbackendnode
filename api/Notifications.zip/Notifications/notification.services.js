const pool = require("../../config/dbconfig");

module.exports = {
  getNotifications: (id, callBack) => {
    pool.query(
      `SELECT id, user_id, message, status, date FROM notifications ORDER BY date DESC`,
      (err, results) => {
        if (err) {
          return callBack(err);
        } else if (!results.length) {
          return callBack("No notifications found");
        } else {
          return callBack(null, results);
        }
      }
    );
  },
};
